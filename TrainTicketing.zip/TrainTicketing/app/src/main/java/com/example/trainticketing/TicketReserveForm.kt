package com.example.trainticketing

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TicketReserveForm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ticket_reserve_form)
    }
}