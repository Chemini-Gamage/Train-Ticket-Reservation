package com.example.trainticketing

class LoginResult {
//    val name: String? = null
//    val email: String? = null
//    val userid: String? = null
//
//
//    fun getName(): String? {
//        return name
//    }
//
//    fun getEmail(): String? {
//        return email
//    }
//
//    fun getUserid(): String? {
//        return userid
//    }


}

