//package com.example.trainticketing
//
//import android.service.autofill.UserData
//import android.telecom.Call
//import retrofit2.Call
//import retrofit2.http.Body
//import retrofit2.http.GET
//import retrofit2.http.POST
//import retrofit2.http.Url
//import kotlin.collections.List
//
//
//import retrofit2.Call
//import retrofit2.http.Body
//import retrofit2.http.GET
//import retrofit2.http.POST
//import retrofit2.http.Query
//import retrofit2.http.Url
//
//interface RetrofitInterface {
//    @POST("User/login")
//    fun executeLogin(@Body map: HashMap<String?, String?>?): Call<LoginResult?>?
//
//    @POST("User")
//    fun executeSignup(@Body map: HashMap<String?, String?>?): Call<Void?>?
//
//    @POST("booking")
//    fun executeReservation(@Body map: HashMap<String?, String?>?): Call<Void?>?
//
//    @get:GET("User")
//    val users: Call<List<Post?>?>?
//
//    @get:GET("trains")
//    val trains: Call<List<Train?>?>?
//
//    //    @GET("User")
//    //    Call<UserData> getProfileData(@Query("userId") String userId);
//    @GET
//    fun getProfileData(@Url url: String?): Call<UserData?>?
//
//    @GET
//    fun getUserReservations(@Url url: String?): Call<List<Reservation?>?>?
//}
