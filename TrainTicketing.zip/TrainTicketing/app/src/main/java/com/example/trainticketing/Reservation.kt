package com.example.trainticketing


class Reservation {
    val cusName: String? = null
    val cusId: String? = null
    val bookdate: String? = null
    val from: String? = null
    val toR: String? = null
    val trainName: String? = null
    val total: String? = null
    val noOfTickets: String? = null
    val traintime: String? = null
}
