package com.example.trainticketing

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlin.collections.List

class SignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
        val signUpButton = findViewById<Button>(R.id.signup)


        signUpButton.setOnClickListener {
            // Call your login function here
            signUp()
        }


    }

    private fun signUp() {
        // Your login logic goes here
        val intent = Intent(this, List::class.java)
        startActivity(intent)
    }


}
