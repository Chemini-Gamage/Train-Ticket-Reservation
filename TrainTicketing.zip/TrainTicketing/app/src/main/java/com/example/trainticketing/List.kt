package com.example.trainticketing

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import kotlin.collections.List

class List : AppCompatActivity() {
    @SuppressLint("WrongViewCast", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        val btnBook = findViewById<Button>(R.id.btnBook)


     btnBook.setOnClickListener {

            btnBook()
        }



    }

    private fun btnBook() {

        val intent = Intent(this, Detail::class.java)
        startActivity(intent)
    }







}