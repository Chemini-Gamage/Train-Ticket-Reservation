//package com.example.trainticketing
//
//ublic class RetrofItClient {
//
//    var retrofit: RetrofIt? = null
//    val BASE_URL = "http://10.0.2.2:5068/api/"
//
//    val retrofitInstance: Retrofit?
//        get() {
//            if (retrofit == null) {
//                retrofit =
//                    Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create())
//                        .build()
//            }
//            return retrofit
//        }
//}
//
//
//
